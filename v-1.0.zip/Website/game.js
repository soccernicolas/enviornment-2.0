let recycle;
let trash;
let xpos, ypos; // Starting position of shape
let score = 0;
let xspeed = 0; // Hosozontal speed of the shape
let yspeed = 3; // Vertical speed of the shape
let life = 3; 
let bottom = 30;
let random;
let item;
let important;

function setup() {
    let cnv = createCanvas (720, 400);
    noStroke();
    frameRate(30);
    fill(250,250,250);
    xpos = width / 2 - 30;
    ypos = 0;
}
function endGame() {
  xspeed = 0;
  yspeed = 0;
  text("GAME OVER", 360, 200) = true;
}
function preload()  {
  recycle = loadImage("https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2Frecycle.png?v=1558967752888");
  let paper = loadImage("https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2FNewspaper.png?1556408834658");
  let water = loadImage("https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2Fwater.png?1556401752650");
  number = Math.random(0,1);
  console.log(number);
  number = Math.round(number);
  console.log(number);
  if (number == 0) {
      item = paper;
}   else {
      item = water;
}
  if (item == paper)  {
    important = true;
}  else {
    important = false
}
  console.log(important);
}
function draw() {
  background(66, 245, 182);
  fill(64, 81, 237);
  let right = rect(500, 400, 120, -120);
  fill(64, 237, 119);
  let left = rect(100, 400, 120, -120);
  fill(0,0,0);
  textSize(35);
  text("paper", 517, 305);
  textSize(40);
  text("plastic", 103, 310);
  image(recycle, 123, 315, 80, 80);
  image(recycle, 525, 320, 75, 75);
  text("score: " +score, 50, 50);
  text("life: " +life, 250, 50);
  if (item == loadImage("https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2FNewspaper.png?1556408834658")) {
      image(item, xpos, ypos, 75, 10000);
  }  else{
  image(item, xpos, ypos, 75, 100);
  }
  xpos = xpos + xspeed;
  ypos = ypos + yspeed;
  if (ypos == 300)  {
  if (important == true)  {
    if (xpos >380 && xpos <620)   {
      score +=1;
      ypos=0;
      xpos=width/2-30;
      xspeed=0;
      yspeed=3;
    }  else {
      life -=1;
      ypos=0;
      xpos=width/2-30;
      xspeed=0;
      yspeed=3;
    }
}  else {
    if (xpos >100 && xpos <220) {
      score +=1;
      ypos=0;
      xpos=width/2-30;
      xspeed=0;
      yspeed=3;
        }  else  {
          life -=1;
          ypos=0;
          xpos=width/2-30;
          xspeed=0;
          yspeed=3;
      }
    }
    if (life <= 0) {
      endGame();
    }
  }
  function keyPressed() {
    if (key == 'a')  {xspeed=-4}
    if (key == 'd')  {xspeed=4}
    if (key == 's')  {xspeed=0}
}
keyPressed();
}